package com.example.parstagram;

import android.app.Application;

import com.parse.Parse;

public class ParseApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("B8GCnXi8v0fW59m1GtogHyhXngaWi4bh6aqqS3rM")
                .clientKey("Qv4BQS7ta14hTzG8Xe8nOtBAESFFdrvu3axAoxUx")
                .server("https://parseapi.back4app.com")
                .build()
        );
    }
}
